
// package frc.robot.subsystems;

// import edu.wpi.first.wpilibj.ADXL362;
// import edu.wpi.first.wpilibj.SPI;
// import edu.wpi.first.wpilibj.interfaces.Accelerometer;
// import edu.wpi.first.wpilibj2.command.CommandBase;
// import edu.wpi.first.wpilibj2.command.SubsystemBase;

// public class Accel extends SubsystemBase {

//   public Accel(){}

//     Accelerometer accels = new ADXL362(SPI.Port.kMXP, Accelerometer.Range.k8G);
//     double xAccel;
//     double yAccel;
//     double zAccel;
//     double lastXAccel;
//     double lastYAccel;
//     double lastZAccel;
//     boolean run = false;
// }

//     // public void updateAccel(){
//     //     while(run){
//     //         xAccel = accels.getX();
//     //         yAccel = accels.getY();
//     //         zAccel = accels.getZ();
//     //     }
//     // }

//     @Override
//   public void periodic() {
//     // This method will be called once per scheduler run
//             xAccel = accels.getX();
//             yAccel = accels.getY();
//             zAccel = accels.getZ();
//             Console.log(zAccel)
//   }

//     // public static void stopAccelerometer(){
//     //     run = false;
//     // }
// }
